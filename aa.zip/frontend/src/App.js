import React from 'react';
import css from './style.css';
const axios = require('axios');

class App extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      photo: null,
      results: []
    }
  }
  componentDidMount() {
    
  }
    render(){
      return (
          <div>
            <SendFile/>
          </div>
      );
    }
}

class SendFile extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      photo: null,
      results: [],
      loading: false,
      envieiImagem: false
    }
  }
  componentDidMount() {
    
  }
  sendImage(file){
    this.setState({loading: false})
    this.setState({envieiImagem: true})
    const react = this
    this.setState({photo: URL.createObjectURL(file)})
    let formData = new FormData();
    formData.set('file', file);
    axios.post('http://localhost:8080', formData, {
      headers: {
      'Content-Type': 'multipart/form-data'
    }})
    .then(function (response) {
      console.log(response.data)
      react.setState({results: response.data})
      react.setState({loading: true})
      console.log(this.state.results)
    })
    .catch(function (error) {
      console.log(error);
    });
  }
  render(){
    return (
          <div className="container">
            <h1>Envie um arquivo</h1>
            <input onChange={(e) => this.sendImage(e.target.files[0])} type='file'></input>
            <br></br>
            {
            this.state.photo != null &&
            <img className="previewImage" src={this.state.photo}/>
            }
            <div className="right">
              <h1>
                { !this.state.loading 
                && this.state.envieiImagem
                && "Fazendo upload!" }
              </h1>
              {
              this.state.loading && 
              this.state.results.predictions.map((item, i) =>
                <div>
                  { item.probability >= 0.7 &&
                  item.tagName != "Latinha" &&
                  <li>
                    { item.tagName }
                  </li>
                  }
                </div>
              )}
            </div>
          </div>
      );
    }
}

export default App;
