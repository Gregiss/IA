<?php

namespace Classes;

use GuzzleHttp\Exception\ClientException;
use GuzzleHttp\Client;

require './Config/VisaoComputacional.php';

class VisaoComputacional {

    private $proxySenai;

    public function __construct($proxySenai = false) {
        $this->proxySenai = $proxySenai;
    }

    private function getProxyConfig(): array {

        $proxy = [];

        if ($this->proxySenai) {
            $proxy = [
                'http' => '10.1.21.254:3128',
                'https' => '10.1.21.254:3128',
                'no' => []
            ];
        }

        return $proxy;
    }

    /**
     * @param string $tipo arquivo ou url
     */
    public function predizer(string $imagem, string $tipo = 'arquivo') {

        $config = \Config\VisaoComputacional::getConfig();

        //Cria um cliente para consumir a API do Windows Azure
        $urlBase = $config ['endpoint'];
        $client = new Client(['base_uri' => $urlBase]);

        try {

            if ($tipo == 'arquivo') {
                $contentType = 'application/octet-stream';
                $dataImage = file_get_contents($imagem);
                $recurso = "/customvision/v3.0/Prediction/88ee6804-83c2-462d-b96e-e59d5e4a526d/classify/iterations/Iteration3/image";
            } else {
                $contentType = 'application/json';
                $dataImage = json_encode(array('url' => $imagem));
                $recurso = "/customvision/v3.0/Prediction/88ee6804-83c2-462d-b96e-e59d5e4a526d/classify/iterations/Iteration3/url";
            }

            $response = $client->post($recurso, array(
                'query' => array(),
                'headers' => array(
                    'Prediction-Key' => $config ['key'],
                    'Content-Type' => $contentType
                ),
                'body' => $dataImage,
                'proxy' => $this->getProxyConfig()
            ));

            return json_decode($response->getBody());
        } catch (ClientErrorResponseException $exception) {
            echo $exception;
        }
    }

}
