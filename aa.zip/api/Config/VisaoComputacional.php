<?php

namespace Config;

class VisaoComputacional {

    public static function getConfig(): array {

        $ApiEndpoint = "https://desafio.cognitiveservices.azure.com";
        $ApiKey = "3764061757224867ada445c307bc30a7";

        $config ['endpoint'] = $ApiEndpoint;
        $config ['key'] = $ApiKey;
        
        return $config;
    }

}

?>