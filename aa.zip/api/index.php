<?php
header('Access-Control-Allow-Origin: *');
header('Content-type: application/json');
header('Access-Control-Allow-Methods: POST, GET, PUT, DELETE');
require_once "vendor/autoload.php";
require './Classes/VisaoComputacional.php';

use Classes\VisaoComputacional;

$visao = new VisaoComputacional(true);

if(isset($_FILES['file'])){
    $destino = "./in/".$_FILES["file"]['name'];
    $arquivo = $destino;
    move_uploaded_file($_FILES['file']['tmp_name'], $destino);
    $retorno = $visao->predizer($arquivo, "arquivo");
    echo json_encode($retorno);
    unlink($destino);
} else{
    $array = Array();
    $array['status'] = "Erro";
    $array['message'] = "Envie um arquivo";
    echo json_encode($array);
    return;
}
?>